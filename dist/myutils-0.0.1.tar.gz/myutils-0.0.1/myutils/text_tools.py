def count_words(text):
    return len(text.split())
